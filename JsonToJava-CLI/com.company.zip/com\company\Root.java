package com.company;



public class Root{

    private static final String FIELD_JOKE = "Joke";


    private Joke Joke;


    public Root(){

    }

    public void set_Joke(Joke joke) {
        Joke = joke;
    }

    public Joke get_Joke() {
        return Joke;
    }


}