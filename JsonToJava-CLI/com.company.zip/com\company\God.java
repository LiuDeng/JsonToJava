package com.company;



public class God{





    public God(){

    }


}