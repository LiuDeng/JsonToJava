package com.company;

import com.google.gson.annotations.SerializedName;


public class God{





    public God(){

    }


}