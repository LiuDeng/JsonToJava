package com.company;



public class T{

    private static final String FIELD_$DATE = "$date";


    private Long $date;


    public T(){

    }

    public void set_$date(Long $date) {
        $date = $date;
    }

    public Long get_$date() {
        return $date;
    }


}